/* Core file: storage, age calc, breeds, helpers */

function getAnimals(){ return JSON.parse(localStorage.getItem('animals') || '[]'); }
function saveAnimals(list){ localStorage.setItem('animals', JSON.stringify(list)); }

/* Gestation lookup (days) */
const gestation = { cow:283, goat:150, sheep:152, pig:115 };

/* Breeds (used by add form). Kept in JS to avoid requiring fetch for simple setups; breeds.json also exists. */
const breedsBySpecies = {
  cow: ['Simbra','Holstein','Angus','Jersey','Hereford'],
  goat: ['Boergoat','Nubian','Kiko','Saanen'],
  sheep: ['Dorset','Suffolk','Merino'],
  pig: ['Large White','Berkshire','Duroc']
};

/* AGE CALCULATION */
function getAgeFromDOB(dob){
  if(!dob) return null;
  const birth = new Date(dob);
  const today = new Date();
  let years = today.getFullYear() - birth.getFullYear();
  let months = today.getMonth() - birth.getMonth();
  let days = today.getDate() - birth.getDate();
  if(days < 0){ months--; const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0); days += prevMonth.getDate(); }
  if(months < 0){ years--; months += 12; }
  return { years, months, days };
}
function formatAge(dob){ const a = getAgeFromDOB(dob); if(!a) return '-'; return `${a.years}y ${a.months}m ${a.days}d`; }

function formatDate(d){ if(!d) return '-'; return new Date(d).toISOString().split('T')[0]; }

/* Expected birth from breeding date */
function calcBirth(type, breedDate){
  if(!breedDate || !gestation[type]) return { dueDate:'-', daysLeft:'-' };
  const d = new Date(breedDate);
  d.setDate(d.getDate() + gestation[type]);
  const diff = Math.ceil((d - new Date())/(1000*60*60*24));
  return { dueDate: d.toISOString().split('T')[0], daysLeft: diff >= 0 ? diff : 'Overdue' };
}

/* Populate breeds dropdown from file or local map */
function loadBreedsFromFile(speciesId, breedId){
  const speciesEl = document.getElementById(speciesId);
  const breedEl = document.getElementById(breedId);
  if(!speciesEl || !breedEl) return;

  // try fetch breeds.json first (if present)
  fetch('breeds.json').then(r => r.json()).then(data => {
    speciesEl.innerHTML = Object.keys(data).map(s=>`<option value="${s}">${s}</option>`).join('');
    function update(){
      const list = data[speciesEl.value] || [];
      breedEl.innerHTML = list.map(b=>`<option value="${b}">${b}</option>`).join('');
    }
    speciesEl.addEventListener('change', update);
    update();
  }).catch(_ => {
    // fallback to embedded map
    speciesEl.innerHTML = Object.keys(breedsBySpecies).map(s=>`<option value="${s}">${s}</option>`).join('');
    function update(){
      const list = breedsBySpecies[speciesEl.value] || [];
      breedEl.innerHTML = list.map(b=>`<option value="${b}">${b}</option>`).join('');
    }
    speciesEl.addEventListener('change', update);
    update();
  });
}

/* File reader helper (photo to dataURL) */
function readImageFile(file, cb){ const fr = new FileReader(); fr.onload = ()=>cb(fr.result); fr.readAsDataURL(file); }

/* Add weight entry */
function addWeight(animalId, weight){
  const animals = getAnimals();
  const a = animals.find(x => String(x.id) === String(animalId));
  if(!a) return;
  a.weights = a.weights || [];
  a.weights.unshift({ date: new Date().toISOString().split('T')[0], weight: parseFloat(weight) });
  saveAnimals(animals);
}

/* Remove animal */
function removeAnimal(id){
  if(!confirm('Delete this animal?')) return;
  const animals = getAnimals().filter(a => String(a.id) !== String(id));
  saveAnimals(animals);
  window.location.href = 'view.html';
}

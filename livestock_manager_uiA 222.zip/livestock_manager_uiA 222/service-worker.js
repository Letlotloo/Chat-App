// simple offline cache
self.addEventListener('install', event => {
  event.waitUntil(caches.open('livestock-v1').then(c =>
    c.addAll(['index.html','add.html','view.html','dashboard.html','profile.html','feeding.html','medication.html','style.css','app.js','view.js','profile.js','dashboard.js','age.js','breeds.json','icons/icon.svg'])
  ));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});

// render animals list
document.addEventListener('DOMContentLoaded', function(){
  const container = document.getElementById('animalList');
  if(!container) return;
  const animals = getAnimals();
  if(animals.length === 0){
    container.innerHTML = '<p>No animals yet. <a href="add.html">Add one</a>.</p>';
    return;
  }
  container.innerHTML = '';
  animals.forEach(a => {
    const age = formatAge(a.dob);
    const b = calcBirth(a.type, a.breedDate);
    const card = document.createElement('div'); card.className = 'animal-card';
    card.innerHTML = `
      <div style="display:flex;gap:12px;align-items:center">
        <img src="${a.photo || 'icons/icon.svg'}" class="profile-photo" />
        <div style="flex:1">
          <h3>${a.name}</h3>
          <p><strong>Type:</strong> ${a.type} • <strong>Breed:</strong> ${a.breed || '-'}</p>
          <p><strong>DOB:</strong> ${formatDate(a.dob)} • <strong>Age:</strong> ${age}</p>
          <p><strong>Breeding Date:</strong> ${formatDate(a.breedDate)}</p>
          <p><strong>Expected Birth:</strong> ${b.dueDate} • <strong>Days Left:</strong> ${b.daysLeft}</p>
          <div style="margin-top:8px"><a class="btn-link" href="profile.html?id=${a.id}">Open Profile</a> <button onclick="removeAnimal('${a.id}')">Delete</button></div>
        </div>
      </div>`;
    container.appendChild(card);
  });
});

package com.prog5121.poe;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();
        MessageManager manager = new MessageManager();

        System.out.println("--- PROG5121 Chat App (Simplified) ---");

        // Simple registration (for demo)
        System.out.print("Enter first name: ");
        String first = input.nextLine();
        System.out.print("Enter last name: ");
        String last = input.nextLine();

        System.out.print("Create a username (must contain _ and <=5 chars): ");
        String username = input.nextLine();
        System.out.print("Create a password: ");
        String password = input.nextLine();
        System.out.print("Enter cell phone with international code (e.g. +2783...): ");
        String phone = input.nextLine();

        String regMsg = login.registerUser(username, password, phone, first, last);
        System.out.println(regMsg);

        // attempt login
        System.out.print("Login - enter username: ");
        String lu = input.nextLine();
        System.out.print("Login - enter password: ");
        String lp = input.nextLine();
        boolean ok = login.loginUser(lu, lp);
        System.out.println(login.returnLoginStatus());
        if (!ok) {
            System.out.println("Cannot continue without login.");
            input.close();
            return;
        }

        System.out.println("Welcome to QuickChat.");
        int totalMessages = 0;

        while (true) {
            System.out.println("Menu:\n1) Send Messages\n2) Show recently sent messages (Coming Soon)\n3) Quit");
            System.out.print("Choose an option: ");
            String choice = input.nextLine();
            if (choice.equals("3")) break;
            if (choice.equals("2")) {
                System.out.println("Coming Soon.");
                continue;
            }
            if (choice.equals("1")) {
                System.out.print("How many messages do you want to create? ");
                int n = Integer.parseInt(input.nextLine());
                for (int i=1;i<=n;i++) {
                    System.out.print("Enter recipient number: ");
                    String recipient = input.nextLine();
                    System.out.print("Enter message (max 250 chars): ");
                    String msg = input.nextLine();
                    if (msg.length() > 250) {
                        System.out.println("Please enter a message of less than 50 characters.");
                        continue;
                    }
                    System.out.println("Choose: 1) Send Message  2) Disregard Message  3) Store Message to send later");
                    String opt = input.nextLine();
                    String status = "DISREGARDED";
                    if (opt.equals("1")) status = "SENT";
                    else if (opt.equals("3")) status = "STORED";
                    Message m = new Message(i, recipient, msg, status);
                    manager.addMessage(m);
                    if (status.equals("SENT")) {
                        System.out.println("Message sent");
                        // display details with JOptionPane requirement simplified to console
                        System.out.println(m.printMessage());
                        totalMessages++;
                    } else if (status.equals("DISREGARDED")) {
                        System.out.println("Press 0 to delete message.");
                    } else {
                        System.out.println("Message successfully stored.");
                    }
                }
                System.out.println("Total messages processed: " + totalMessages);
            }
        }

        // populate arrays with test data for Part 3 as required
        manager.addMessage(new Message(1, "+27834557896", "Did you get the cake?", "SENT"));
        manager.addMessage(new Message(2, "+27838884567", "Where are you? You are late! I have asked you to be on time.", "STORED"));
        manager.addMessage(new Message(3, "+27834484567", "Yohoooo, I am at your gate.", "DISREGARDED"));
        manager.addMessage(new Message(4, "0838884567", "It is dinner time !", "SENT"));
        manager.addMessage(new Message(5, "+27838884567", "Ok, I am leaving without you.", "STORED"));

        // Demonstrate Part 3 features
        System.out.println("\n--- Part 3 Demo Outputs ---");
        System.out.println("Display sender and recipient of all sent messages:");
        manager.displaySenderRecipientOfSent();

        System.out.println("\nLongest sent message:");
        System.out.println(manager.longestSentMessage());

        System.out.println("\nSearch for message ID (enter an ID or press enter to skip):");
        String searchId = input.nextLine();
        if (!searchId.isEmpty()) {
            Message found = manager.findByMessageID(searchId);
            if (found != null) System.out.println(found.printMessage());
            else System.out.println("Message ID not found.");
        }

        System.out.println("\nSearch messages by recipient (enter number or press enter to skip):");
        String rec = input.nextLine();
        if (!rec.isEmpty()) {
            var list = manager.findByRecipient(rec);
            if (list.isEmpty()) System.out.println("No messages for that recipient.");
            else for (Message mm : list) System.out.println(mm.printMessage());
        }

        System.out.println("\nDelete a message by hash (enter hash or press enter to skip):");
        String hash = input.nextLine();
        if (!hash.isEmpty()) {
            boolean deleted = manager.deleteByHash(hash);
            if (deleted) System.out.println("Message successfully deleted.");
            else System.out.println("No message found with that hash.");
        }

        System.out.println("\nDisplay report:");
        manager.displayReport();

        // store stored messages to json and read back
        String jsonPath = "stored_messages.json";
        manager.storeMessagesToJson(jsonPath);
        manager.readMessagesFromJson(jsonPath);
        System.out.println("\nStored messages read from JSON (count): " + manager.getStoredMessages().size());

        input.close();
        System.out.println("Goodbye!");
    }
}

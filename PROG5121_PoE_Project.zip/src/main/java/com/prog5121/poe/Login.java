package com.prog5121.poe;

public class Login {
    private String username;
    private String password;
    private String phone;
    private String firstName;
    private String lastName;
    private boolean registered = false;
    private boolean loggedIn = false;

    public Login() {}

    public boolean checkUserName(String username) {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            if (Character.isDigit(c)) hasDigit = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    public boolean checkCellPhoneNumber(String phone) {
        if (phone == null) return false;
        return phone.matches("^\\+[0-9]{8,12}$");
    }

    public String registerUser(String username, String password, String phone, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(phone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
        this.registered = true;
        return "Username and password successfully captured. Cell phone number successfully added.";
    }

    public boolean loginUser(String username, String password) {
        if (!registered) return false;
        this.loggedIn = this.username.equals(username) && this.password.equals(password);
        return this.loggedIn;
    }

    public String returnLoginStatus() {
        if (loggedIn) {
            return "Welcome " + firstName + " ," + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    public String getUsername(){ return username; }
    public String getPhone(){ return phone; }
    public boolean isRegistered(){ return registered; }
}

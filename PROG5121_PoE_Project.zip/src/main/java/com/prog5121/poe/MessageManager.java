package com.prog5121.poe;

import java.io.*;
import java.util.*;

public class MessageManager {
    private ArrayList<Message> sentMessages = new ArrayList<>();
    private ArrayList<Message> storedMessages = new ArrayList<>();
    private ArrayList<Message> disregardedMessages = new ArrayList<>();

    public MessageManager() {}

    public void addMessage(Message m) {
        if ("SENT".equalsIgnoreCase(m.getStatus())) sentMessages.add(m);
        else if ("STORED".equalsIgnoreCase(m.getStatus())) storedMessages.add(m);
        else disregardedMessages.add(m);
    }

    public ArrayList<Message> getSentMessages(){ return sentMessages; }
    public ArrayList<Message> getStoredMessages(){ return storedMessages; }
    public ArrayList<Message> getDisregardedMessages(){ return disregardedMessages; }

    public void displaySenderRecipientOfSent() {
        System.out.println("Sender (developer) | Recipient");
        for (Message m : sentMessages) {
            System.out.println("Developer | " + m.getRecipient());
        }
    }

    public String longestSentMessage() {
        String longest = "";
        for (Message m : sentMessages) {
            if (m.getMessage().length() > longest.length()) longest = m.getMessage();
        }
        return longest;
    }

    public Message findByMessageID(String id) {
        for (Message m : sentMessages) {
            if (m.getMessageID().equals(id)) return m;
        }
        for (Message m : storedMessages) {
            if (m.getMessageID().equals(id)) return m;
        }
        for (Message m : disregardedMessages) {
            if (m.getMessageID().equals(id)) return m;
        }
        return null;
    }

    public ArrayList<Message> findByRecipient(String recipient) {
        ArrayList<Message> found = new ArrayList<>();
        for (Message m : sentMessages) if (m.getRecipient().equals(recipient)) found.add(m);
        for (Message m : storedMessages) if (m.getRecipient().equals(recipient)) found.add(m);
        for (Message m : disregardedMessages) if (m.getRecipient().equals(recipient)) found.add(m);
        return found;
    }

    public boolean deleteByHash(String hash) {
        Iterator<Message> it = sentMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (m.getMessageHash().equalsIgnoreCase(hash)) {
                it.remove();
                return true;
            }
        }
        it = storedMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (m.getMessageHash().equalsIgnoreCase(hash)) {
                it.remove();
                return true;
            }
        }
        it = disregardedMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (m.getMessageHash().equalsIgnoreCase(hash)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    public void displayReport() {
        System.out.println("===================== MESSAGE REPORT =====================");
        for (Message m : sentMessages) {
            System.out.println(m.printMessage());
        }
        System.out.println("==========================================================");
    }

    public void storeMessagesToJson(String filepath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filepath))) {
            bw.write("[");
            for (int i=0;i<storedMessages.size();i++) {
                Message m = storedMessages.get(i);
                String json = String.format(
                    "{\"messageID\":\"%s\",\"recipient\":\"%s\",\"message\":\"%s\",\"status\":\"%s\"}",
                    escape(m.getMessageID()), escape(m.getRecipient()), escape(m.getMessage()), escape(m.getStatus())
                );
                bw.write(json);
                if (i < storedMessages.size()-1) bw.write(",");
            }
            bw.write("]");
        } catch (IOException e) { e.printStackTrace(); }
    }

    public void readMessagesFromJson(String filepath) {
        storedMessages.clear();
        try {
            String content = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get(filepath)));
            content = content.trim();
            if (content.length() < 2) return;
            if (content.startsWith("[")) {
                content = content.substring(1, content.length()-1).trim();
                if (content.isEmpty()) return;
                String[] items = content.split("},\s*\{");
                for (String item : items) {
                    String s = item;
                    if (!s.startsWith("{")) s = "{" + s;
                    if (!s.endsWith("}")) s = s + "}";
                    Map<String,String> map = parseSimpleJsonObject(s);
                    Message m = new Message(0, map.getOrDefault("recipient",""), map.getOrDefault("message",""), map.getOrDefault("status","STORED"));
                    try {
                        java.lang.reflect.Field f = Message.class.getDeclaredField("messageID");
                        f.setAccessible(true);
                        f.set(m, map.getOrDefault("messageID", m.getMessageID()));
                    } catch (Exception ex) {}
                    storedMessages.add(m);
                }
            }
        } catch (IOException e) {
        }
    }

    private static String escape(String s) {
        return s.replace("\\","\\\\").replace("\"","\\\"");
    }

    private static Map<String,String> parseSimpleJsonObject(String s) {
        Map<String,String> map = new HashMap<>();
        s = s.trim();
        if (s.startsWith("{")) s = s.substring(1);
        if (s.endsWith("}")) s = s.substring(0, s.length()-1);
        String[] pairs = s.split("\",\s*\"");
        for (String p : pairs) {
            p = p.replaceAll("^\"|\"$","");
            String[] kv = p.split("\":\"");
            if (kv.length == 2) {
                map.put(kv[0].replaceAll("^\"|\"$",""), kv[1].replaceAll("^\"|\"$",""));
            }
        }
        return map;
    }
}

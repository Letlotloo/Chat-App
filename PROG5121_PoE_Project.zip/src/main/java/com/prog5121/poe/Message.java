package com.prog5121.poe;

import java.util.UUID;

public class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    private String status;
    private int messageNumber;

    public Message() {}

    public Message(int messageNumber, String recipient, String message, String status) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.status = status;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        long val = Math.abs(UUID.randomUUID().getMostSignificantBits());
        String s = Long.toString(val);
        if (s.length() > 10) return s.substring(0,10);
        while (s.length() < 10) s = "0" + s;
        return s;
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        if (recipient == null) return false;
        return recipient.matches("^\\+[0-9]{8,12}$");
    }

    public String createMessageHash() {
        String firstTwo = messageID.substring(0,2);
        String firstWord = "", lastWord = "";
        String cleaned = message.trim();
        String[] parts = cleaned.split("\\s+");
        if (parts.length > 0) firstWord = parts[0];
        if (parts.length > 1) lastWord = parts[parts.length-1];
        String hashBody = (firstWord + lastWord).toUpperCase().replaceAll("[^A-Z0-9]", "");
        return firstTwo + ":" + messageNumber + ":" + hashBody;
    }

    public String getMessageID(){ return messageID; }
    public String getRecipient(){ return recipient; }
    public String getMessage(){ return message; }
    public String getMessageHash(){ return messageHash; }
    public String getStatus(){ return status; }
    public int getMessageNumber(){ return messageNumber; }

    public String printMessage() {
        return "MessageID: " + messageID + ", Message Hash: " + messageHash + ", Recipient: " + recipient + ", Message: " + message;
    }
}

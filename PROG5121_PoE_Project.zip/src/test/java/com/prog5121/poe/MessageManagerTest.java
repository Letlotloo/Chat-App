package com.prog5121.poe;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class MessageManagerTest {
    @Test
    public void testPopulateSentMessages() {
        MessageManager mm = new MessageManager();
        mm.addMessage(new Message(1, "+27834557896", "Did you get the cake?", "SENT"));
        mm.addMessage(new Message(4, "0838884567", "It is dinner time !", "SENT"));
        ArrayList<Message> sent = mm.getSentMessages();
        assertEquals(2, sent.size());
    }

    @Test
    public void testLongestMessage() {
        MessageManager mm = new MessageManager();
        mm.addMessage(new Message(1, "+27834557896", "Did you get the cake?", "SENT"));
        mm.addMessage(new Message(2, "+27838884567", "Where are you? You are late! I have asked you to be on time.", "STORED"));
        String longest = mm.longestSentMessage();
        assertNotNull(longest);
    }
}

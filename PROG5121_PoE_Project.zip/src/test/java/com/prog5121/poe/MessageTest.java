package com.prog5121.poe;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {
    @Test
    public void testMessageHashAndID() {
        Message m = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight", "SENT");
        assertTrue(m.checkMessageID());
        // recipient must start with + - according to checkRecipientCell
        assertTrue(m.checkRecipientCell());
        String hash = m.getMessageHash();
        assertNotNull(hash);
    }

    @Test
    public void testMessageLength() {
        Message m = new Message(1, "+27718693002", "Short msg", "SENT");
        assertTrue(m.getMessage().length() < 250);
    }
}

package com.prog5121.poe;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    @Test
    public void testUsernameCorrect() {
        Login l = new Login();
        assertTrue(l.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIncorrect() {
        Login l = new Login();
        assertFalse(l.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testPasswordComplexity() {
        Login l = new Login();
        assertTrue(l.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(l.checkPasswordComplexity("password"));
    }

    @Test
    public void testPhone() {
        Login l = new Login();
        assertTrue(l.checkCellPhoneNumber("+27838968976"));
        assertFalse(l.checkCellPhoneNumber("08966553"));
    }
}

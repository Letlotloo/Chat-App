import javax.swing.*;

public class Login {

    public static boolean authenticate() {
        while (true) {
            JPanel panel = new JPanel();
            JTextField userField = new JTextField(10);
            JPasswordField passField = new JPasswordField(10);

            panel.add(new JLabel("Username:"));
            panel.add(userField);
            panel.add(Box.createHorizontalStrut(15));
            panel.add(new JLabel("Password:"));
            panel.add(passField);

            int result = JOptionPane.showConfirmDialog(
                    null, panel, "Login",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
            );

            if (result != JOptionPane.OK_OPTION) {
                return false;
            }

            String username = userField.getText();
            String password = new String(passField.getPassword());

            if ("user".equals(username) && "pass".equals(password)) {
                JOptionPane.showMessageDialog(null, "Login successful.");
                return true;
            } else {
                int retry = JOptionPane.showConfirmDialog(
                        null, "Invalid credentials. Try again?",
                        "Login failed", JOptionPane.YES_NO_OPTION
                );
                if (retry != JOptionPane.YES_OPTION) return false;
            }
        }
    }
}

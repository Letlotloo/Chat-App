import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

public class QuickChat {

    private static final int MAX_MESSAGE_LENGTH = 50;
    private static final Pattern RECIPIENT_PATTERN = Pattern.compile("^\+\d{1,9}$");
    private static final Random RANDOM = new Random();

    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static int messageCounter = 0;

    public static void main(String[] args) {
        if (!Login.authenticate()) {
            JOptionPane.showMessageDialog(null, "Login required. Exiting application.");
            System.exit(0);
        }

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        int allowedMessages = askForNumberOfMessages();
        if (allowedMessages <= 0) {
            JOptionPane.showMessageDialog(null, "No messages allowed. Exiting.");
            System.exit(0);
        }

        boolean exit = false;
        while (!exit) {
            String menu = "Choose an option:\n1) Send Messages\n2) Show recently sent messages\n3) Quit";
            String choiceStr = JOptionPane.showInputDialog(null, menu, "Menu", JOptionPane.QUESTION_MESSAGE);
            if (choiceStr == null) choiceStr = "3";

            int choice;
            try {
                choice = Integer.parseInt(choiceStr.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a numeric option (1–3).");
                continue;
            }

            switch (choice) {
                case 1 -> {
                    if (sentMessages.size() >= allowedMessages) {
                        JOptionPane.showMessageDialog(null, "You have reached the allowed number of sent messages (" + allowedMessages + ").");
                        break;
                    }
                    composeAndHandleMessage(allowedMessages);
                }
                case 2 -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                case 3 -> {
                    JOptionPane.showMessageDialog(null,
                            "Total messages sent: " + sentMessages.size() +
                                    "\nMessages stored for later: " + storedMessages.size(),
                            "Summary", JOptionPane.INFORMATION_MESSAGE);
                    exit = true;
                }
                default -> JOptionPane.showMessageDialog(null, "Please choose a valid option (1–3).");
            }
        }

        JOptionPane.showMessageDialog(null, "Goodbye. Total messages sent: " + sentMessages.size());
        System.exit(0);
    }

    private static int askForNumberOfMessages() {
        while (true) {
            String input = JOptionPane.showInputDialog(null,
                    "Define how many messages you wish to enter (positive integer):",
                    "Number of messages", JOptionPane.QUESTION_MESSAGE);
            if (input == null) return 0;
            try {
                int n = Integer.parseInt(input.trim());
                if (n > 0) return n;
                JOptionPane.showMessageDialog(null, "Please enter a positive integer.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Enter a valid integer.");
            }
        }
    }

    private static void composeAndHandleMessage(int allowedMessages) {
        String recipient = JOptionPane.showInputDialog(null,
                "Enter recipient (start with +, max 10 chars):", "Recipient", JOptionPane.QUESTION_MESSAGE);
        if (recipient == null) return;
        recipient = recipient.trim();

        if (recipient.length() > 10 || !RECIPIENT_PATTERN.matcher(recipient).matches()) {
            JOptionPane.showMessageDialog(null, "Invalid recipient. Must start with '+' and be ≤10 chars.");
            return;
        }

        String msg = JOptionPane.showInputDialog(null,
                "Enter message (max " + MAX_MESSAGE_LENGTH + " chars):", "Message", JOptionPane.QUESTION_MESSAGE);
        if (msg == null) return;
        msg = msg.trim();

        if (msg.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message cannot be empty.");
            return;
        }
        if (msg.length() > MAX_MESSAGE_LENGTH) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.");
            return;
        }

        String messageId = generate10DigitId();
        int msgNum = messageCounter;
        String messageHash = generateMessageHash(messageId, msgNum, msg);
        Message message = new Message(messageId, messageHash, recipient, msg);

        String[] options = {"Send Message", "Disregard Message", "Store Message (send later)", "Store Message in JSON file"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an action for this message:",
                "Message Actions", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0 -> {
                messageCounter++;
                message.setMessageNumber(messageCounter);
                sentMessages.add(message);
                showMessageDetails(message);
                JOptionPane.showMessageDialog(null, "Message sent.");
            }
            case 1 -> JOptionPane.showMessageDialog(null, "Message disregarded.");
            case 2 -> {
                storedMessages.add(message);
                JOptionPane.showMessageDialog(null, "Message stored to send later.");
            }
            case 3 -> {
                try {
                    appendMessageToJsonFile(message);
                    storedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message stored in messages.json.");
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Failed to write JSON file: " + e.getMessage());
                }
            }
            default -> JOptionPane.showMessageDialog(null, "No action selected. Returning to menu.");
        }

        if (sentMessages.size() >= allowedMessages) {
            JOptionPane.showMessageDialog(null, "All allowed messages have been sent (" + allowedMessages + ").");
        }
    }

    private static void showMessageDetails(Message m) {
        StringBuilder sb = new StringBuilder();
        sb.append("MessageID: ").append(m.getId()).append("\n");
        sb.append("Message Hash: ").append(m.getHash()).append("\n");
        sb.append("Recipient: ").append(m.getRecipient()).append("\n");
        sb.append("Message: ").append(m.getMessage());
        JOptionPane.showMessageDialog(null, sb.toString(), "Message Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private static String generate10DigitId() {
        long min = 1_000_000_000L;
        long max = 9_999_999_999L;
        long value = min + (long) (RANDOM.nextDouble() * (max - min + 1));
        return Long.toString(value);
    }

    private static String generateMessageHash(String id, int msgNum, String message) {
        String firstTwo = id.substring(0, 2);
        String numStr = String.valueOf(msgNum);
        String[] words = message.split("\\s+");
        String first = words[0];
        String last = words.length > 1 ? words[words.length - 1] : first;
        return (firstTwo + ":" + numStr + ":" + (first + last).toUpperCase());
    }

    private static void appendMessageToJsonFile(Message m) throws IOException {
        File file = new File("messages.json");
        String json = messageToJsonString(m);

        if (!file.exists()) {
            try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
                w.write("[\n" + json + "\n]");
            }
            return;
        }

        String content = "";
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            content = sb.toString().trim();
        }

        int lastBracket = content.lastIndexOf(']');
        if (lastBracket == -1) {
            try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
                w.write("[\n" + json + "\n]");
            }
            return;
        }

        String newContent = content.substring(0, lastBracket);
        if (!newContent.trim().endsWith("[")) newContent += ",\n";
        newContent += json + "\n]";

        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            w.write(newContent);
        }
    }

    private static String messageToJsonString(Message m) {
        return "  {\n" +
                "    \"messageId\": \"" + escapeJson(m.getId()) + "\",\n" +
                "    \"messageHash\": \"" + escapeJson(m.getHash()) + "\",\n" +
                "    \"recipient\": \"" + escapeJson(m.getRecipient()) + "\",\n" +
                "    \"message\": \"" + escapeJson(m.getMessage()) + "\"\n" +
                "  }";
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private static class Message {
        private final String id;
        private final String hash;
        private final String recipient;
        private final String message;
        private int messageNumber;

        public Message(String id, String hash, String recipient, String message) {
            this.id = id;
            this.hash = hash;
            this.recipient = recipient;
            this.message = message;
        }

        public String getId() { return id; }
        public String getHash() { return hash; }
        public String getRecipient() { return recipient; }
        public String getMessage() { return message; }
        public void setMessageNumber(int num) { this.messageNumber = num; }
    }
}
